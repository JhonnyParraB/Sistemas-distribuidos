import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

import org.omg.CORBA.PRIVATE_MEMBER;

import com.sun.org.apache.bcel.internal.generic.Select;

import javafx.scene.control.Tab;

public class Coordinador extends UnicastRemoteObject implements CoordinadorIF{
	
	protected Coordinador() throws RemoteException {
		super();
		listaTransacciones= new ArrayList<>();
		listaParticipantes = new ArrayList<>();
		// TODO Auto-generated constructor stub
	}



	private ArrayList<Participante> listaParticipantes;
	private ArrayList<Transaccion> listaTransacciones;

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static void main(String[] args) throws RemoteException {
		 Registry registry= LocateRegistry.createRegistry(1234);
		 registry.rebind("12345", new Coordinador());
		 registry.rebind("56789", new Coordinador());
		 registry.rebind("13579", new Coordinador());
		 registry.rebind("24568", new Coordinador());
		 registry.rebind("00000", new Coordinador());
		 registry.rebind("11335", new Coordinador());

	}






	@Override
	public String openTransacccion(String user, String selec, Ahorro ad, Credito cd, Visa vd, MasterCard md, int cant)//lectura
			throws RemoteException {
		// TODO Auto-generated method stub
		if(selec.equalsIgnoreCase("A")){
			if(ad!=null&&cd==null&&vd==null&&md==null)
				return String.valueOf(ad.getBalance());
			if(cd!=null&&vd==null&&md==null&&ad==null)
				return String.valueOf(cd.getBalance());
			if(vd!=null&&md==null&&cd==null&&ad==null)				
				return "cupo: "+String.valueOf(vd.getCupoVisa())+ " "+ " deuda: "+String.valueOf(vd.getDeudaVisa());
			if(md!=null&&vd==null&&cd==null&&ad==null)				
				return "cupo: "+String.valueOf(md.getCupoMC())+ " "+ " deuda: "+String.valueOf(md.getDeudaMC());
			if(ad!=null && cd!=null && vd!=null && md!=null ) {
				return "disponible Ahorros: "+String.valueOf(ad.getBalance())+ " disponible Credito: "+ String.valueOf(cd.getBalance())
						+ "cupo Visa: "+String.valueOf(vd.getCupoVisa())+ " "+ "deuda Visa: "+String.valueOf(vd.getDeudaVisa())+ " "+ "cupo Master: "+
						String.valueOf(md.getCupoMC())+ " "+ " deuda MAster: "+String.valueOf(vd.getDeudaVisa());
			}
		}
		if(selec.equalsIgnoreCase("C")) {
			if(ad!=null&&vd!=null&&cd==null&&md==null) {
				Boolean docommit=false;
				
					Transaccion transaccion= new Transaccion(user, "Pagar", cant);
					listaTransacciones.add(transaccion);
					Participante participante= new Participante(this);
					listaParticipantes.add(participante);
					for(Participante p:listaParticipantes)
						if(p.canComit(listaTransacciones, transaccion, vd, ad))
							docommit=true;
					if(docommit)
						for(Participante p:listaParticipantes)
							p.doCommit(vd, ad);
					return "transaccion consumada";
			}
			if(ad==null&&vd!=null&&cd!=null&&md==null) {
				Boolean docommit=false;
				
					Transaccion transaccion= new Transaccion(user, "Pagar", cant);
					listaTransacciones.add(transaccion);
					Participante participante= new Participante(this);
					listaParticipantes.add(participante);
					for(Participante p:listaParticipantes)
						if(p.canComit(listaTransacciones, transaccion, vd, cd))
							docommit=true;
					if(docommit)
						for(Participante p:listaParticipantes)
							p.doCommit(vd, cd);
					return "transaccion consumada";
			}
			if(ad!=null&&vd==null&&cd==null&&md!=null) {
				Boolean docommit=false;
				
					Transaccion transaccion= new Transaccion(user, "pagar", cant);
					listaTransacciones.add(transaccion);
					Participante participante= new Participante(this);
					listaParticipantes.add(participante);
					for(Participante p:listaParticipantes)
						if(p.canComit(listaTransacciones, transaccion, ad, md))
							docommit=true;
					if(docommit)
						for(Participante p:listaParticipantes)
							p.doCommit(ad, md);
					return "transaccion consumada";
			}

			if(ad==null&&vd==null&&cd!=null&&md!=null) {
				Boolean docommit=false;
				
					Transaccion transaccion= new Transaccion(user, "pagar", cant);
					listaTransacciones.add(transaccion);
					Participante participante= new Participante(this);
					listaParticipantes.add(participante);
					for(Participante p:listaParticipantes)
						if(p.canComit(listaTransacciones, transaccion, cd, md))
							docommit=true;
					if(docommit)
						for(Participante p:listaParticipantes)
							p.doCommit(cd, md);
					return "transaccion consumada";
			}

			
			
		}
		
		return "transaciion finalizada sin exito";
		
	}



	@Override
	public String openTransacccion(String user, String selec, MasterCard md,int cant) throws RemoteException {
		// TODO Auto-generated method stub
		return user+String.valueOf(serialVersionUID);
		
	}



	@Override
	public String openTransacccion(String user, String selec, Credito cd,int cant) throws RemoteException {
		// TODO Auto-generated method stub
		return user+String.valueOf(serialVersionUID);
	}



	@Override
	public String openTransacccion(String user, String selec, Ahorro ad, int cant) throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}






	@Override
	public String openTransacccion(String user, String selec, Ahorro ad, Ahorro ad2, int result)
			throws RemoteException {
		Boolean docommit=false;
		if(selec.equalsIgnoreCase("B")) {
			Transaccion transaccion= new Transaccion(user, "transferir", result);
			listaTransacciones.add(transaccion);
			Participante participante= new Participante(this);
			listaParticipantes.add(participante);
			for(Participante p:listaParticipantes)
				if(p.canComit(listaTransacciones, transaccion, ad, ad2))
					docommit=true;
			if(docommit)
				for(Participante p:listaParticipantes)
					participante.doCommit(ad, ad2);
			return "transaccion consumada";
		}

		return "transaccion no exitosa";
		
	}






	@Override
	public String openTransacccion(String user, String selec, Ahorro ad, Credito cd, int result) throws RemoteException {
		// TODO Auto-generated method stub
		Boolean docommit=false;
		if(selec.equalsIgnoreCase("0")) {
			Transaccion transaccion= new Transaccion(user, "transferir", result);
			listaTransacciones.add(transaccion);
			Participante participante= new Participante(this);
			listaParticipantes.add(participante);
			for(Participante p:listaParticipantes)
				if(p.canComit(listaTransacciones, transaccion, ad, cd))
					docommit=true;
			if(docommit)
				for(Participante p:listaParticipantes)
					p.doCommit(ad, cd);
			return "transaccion consumada";
		}
		if(selec.equalsIgnoreCase("1")) {
			Transaccion transaccion= new Transaccion(user, "transferir", result);
			listaTransacciones.add(transaccion);
			Participante participante= new Participante(this);
			listaParticipantes.add(participante);
			for(Participante p:listaParticipantes)
				if(p.canComit(listaTransacciones, transaccion, cd, ad))
					docommit=true;
			if(docommit)
				for(Participante p:listaParticipantes)
					p.doCommit(cd, ad);
			return "transaccion consumada";
		}

		return "transaccion no exitosa";
	}






	@Override
	public String openTransacccion(String user, String selec, Credito cd, Credito cd2, int result) throws RemoteException {
		// TODO Auto-generated method stub
		Boolean docommit=false;
		if(selec.equalsIgnoreCase("B")) {
			Transaccion transaccion= new Transaccion(user, "transferir", result);
			listaTransacciones.add(transaccion);
			Participante participante= new Participante(this);
			listaParticipantes.add(participante);
			for(Participante p:listaParticipantes)
				if(p.canComit(listaTransacciones, transaccion, cd, cd2))
					docommit=true;
			if(docommit)
				for(Participante p:listaParticipantes)
					p.doCommit(cd, cd2);
			return "transaccion consumada";
		}

		return "transaccion no exitosa";

	
	}








}
