import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author Juan Vales
 */
public interface CoordinadorIF extends Remote
{
    

	public String openTransacccion(String user, String selec, Ahorro ad, Credito cd, Visa vd, MasterCard md, int cantidad) throws RemoteException;

	public String openTransacccion(String user, String selec, MasterCard md, int cantidad)throws RemoteException;

	public String openTransacccion(String user, String selec, Credito cd, int cantidad)throws RemoteException;

	public String openTransacccion(String user, String selec, Ahorro ad, int cantidad)throws RemoteException;

	public String openTransacccion(String user, String selec, Ahorro ad, Ahorro ad2, int result)throws RemoteException; //transferencia ahorro a ahorro;

	public String openTransacccion(String user, String selec, Ahorro ad, Credito cd, int result) throws RemoteException;

	public String openTransacccion(String user, String selec, Credito cd, Credito cd2, int result) throws RemoteException;
}
