import java.rmi.RemoteException;
import java.util.ArrayList;

public class Participante {
	private Coordinador coordinador;
	private int tentativa1;
	private int tentativa2;

	public Participante(Coordinador coordinador) {
		super();
		this.coordinador = coordinador;
	}
	public boolean canComit(ArrayList<Transaccion> transaccions,Transaccion transaccion, Ahorro ad, Ahorro ad2) throws RemoteException {
		if(ad.getBalance()<transaccion.monto)
			return false;
		for(Transaccion t: transaccions) {
			if (t.peticion.equals("transferencia")&&t.startTn.after(transaccion.startTn)&&transaccion.peticion.equals("write")) {
				return false;
				
			}
		}
		tentativa1=ad.getBalance()-transaccion.monto;
		System.out.println(tentativa1+ " "+ tentativa2);
		tentativa2=ad2.getBalance()+transaccion.monto;
		System.out.println(tentativa2);
		
		return true;
	}
	public void doCommit(Ahorro ad, Ahorro ad2) throws RemoteException {
		ad.setBalance(tentativa1);
		ad2.setBalance(tentativa2);
	}
	public boolean canComit(ArrayList<Transaccion> listaTransacciones, Transaccion transaccion, Ahorro ad, Credito cd) throws RemoteException {
		// TODO Auto-generated method stub
		if(ad.getBalance()<transaccion.monto)
			return false;
		for(Transaccion t: listaTransacciones) {
			if (t.peticion.equals("transferencia")&&t.startTn.after(transaccion.startTn)&&transaccion.peticion.equals("write")) {
				return false;
				
			}
		}
		tentativa1=ad.getBalance()-transaccion.monto;
		tentativa2=cd.getBalance()+transaccion.monto;
		
		return true;
		
	}
	public void doCommit(Ahorro ad, Credito cd) throws RemoteException {
		// TODO Auto-generated method stub
		ad.setBalance(tentativa1);
		cd.setBalance(tentativa2);
	}
	public boolean canComit(ArrayList<Transaccion> listaTransacciones, Transaccion transaccion, Credito cd, Ahorro ad) throws RemoteException {
		// TODO Auto-generated method stub
		if(cd.getBalance()<transaccion.monto)
			return false;
		for(Transaccion t: listaTransacciones) {
			if (t.peticion.equals("transferencia")&&t.startTn.after(transaccion.startTn)&&transaccion.peticion.equals("write")) {
				return false;
				
			}
		}
		tentativa1=cd.getBalance()-transaccion.monto;
		tentativa2=ad.getBalance()+transaccion.monto;
		
		return true;
	}

	public boolean canComit(ArrayList<Transaccion> listaTransacciones, Transaccion transaccion, Credito cd,
			Credito cd2) throws RemoteException {
		// TODO Auto-generated method stub
		if(cd.getBalance()<transaccion.monto)
			return false;
		for(Transaccion t: listaTransacciones) {
			if (t.peticion.equals("Transferencia")&&t.startTn.after(transaccion.startTn)&&transaccion.peticion.equals("write")) {
				return false;
				
			}
		}
		tentativa1=cd.getBalance()-transaccion.monto;
		tentativa2=cd2.getBalance()+transaccion.monto;
		
		return true;
	
	}
	public void doCommit(Credito cd, Credito cd2) throws RemoteException {
		// TODO Auto-generated method stub
		cd.setBalance(tentativa1);
		cd2.setBalance(tentativa2);
		
	}
	public boolean canComit(ArrayList<Transaccion> listaTransacciones, Transaccion transaccion, Visa vd, Ahorro ad) throws RemoteException {
		// TODO Auto-generated method stub
		if(ad.getBalance()<transaccion.monto)
			return false;
		for(Transaccion t: listaTransacciones) {
			if (t.peticion.equals("pagar")&&t.startTn.after(transaccion.startTn)&&transaccion.peticion.equals("write")) {
				return false;
				
			}
		}
		tentativa1=ad.getBalance()-transaccion.monto;
		tentativa2=vd.getDeudaVisa()-transaccion.monto;
		
		return true;
	}
	public void doCommit(Visa vd, Ahorro ad) throws RemoteException {
		ad.setBalance(tentativa1);
		vd.setDeudaVisa(tentativa2);
		// TODO Auto-generated method stub
		
	}
	public boolean canComit(ArrayList<Transaccion> listaTransacciones, Transaccion transaccion, Visa vd, Credito cd) throws RemoteException {
		// TODO Auto-generated method stub
		if(cd.getBalance()<transaccion.monto)
			return false;
		for(Transaccion t: listaTransacciones) {
			if (t.peticion.equals("Pagar")&&t.startTn.after(transaccion.startTn)&&transaccion.peticion.equals("write")) {
				return false;
				
			}
		}
		tentativa1=cd.getBalance()-transaccion.monto;
		tentativa2=vd.getDeudaVisa()-transaccion.monto;
		
		return true;
	}
	public void doCommit(Credito cd, Ahorro ad) throws RemoteException {
		// TODO Auto-generated method stub
		cd.setBalance(tentativa1);
		ad.setBalance(tentativa2);
		
	}
	public void doCommit(Visa vd, Credito cd) throws RemoteException {
		cd.setBalance(tentativa1);
		vd.setDeudaVisa(tentativa2);
	}
	public void doCommit(Ahorro ad, MasterCard md) throws RemoteException {
		// TODO Auto-generated method stub
		ad.setBalance(tentativa1);
		md.setDeudaMC(tentativa2);
		
	}
	public boolean canComit(ArrayList<Transaccion> listaTransacciones, Transaccion transaccion, Ahorro ad,
			MasterCard md) throws RemoteException {
		// TODO Auto-generated method stub
		
		if(ad.getBalance()<transaccion.monto)
			return false;
		for(Transaccion t: listaTransacciones) {
			if (t.peticion.equals("Pagar")&&t.startTn.after(transaccion.startTn)&&transaccion.peticion.equals("write")) {
				return false;
				
			}
		}
		tentativa1=ad.getBalance()-transaccion.monto;
		tentativa2=md.getDeudaMC()-transaccion.monto;
		
		return true;
	}
	public boolean canComit(ArrayList<Transaccion> listaTransacciones, Transaccion transaccion, Credito cd,
			MasterCard md) throws RemoteException {
		// TODO Auto-generated method stub
		
		if(cd.getBalance()<transaccion.monto)
			return false;
		for(Transaccion t: listaTransacciones) {
			if (t.peticion.equals("Pagar")&&t.startTn.after(transaccion.startTn)&&transaccion.peticion.equals("write")) {
				return false;
				
			}
		}
		tentativa1=cd.getBalance()-transaccion.monto;
		tentativa2=md.getDeudaMC()-transaccion.monto;
		
		return true;
	}
	public void doCommit(Credito cd, MasterCard md) throws RemoteException {
		// TODO Auto-generated method stub
		cd.setBalance(-tentativa1);
		md.setDeudaMC(tentativa2);
		
	}

}
