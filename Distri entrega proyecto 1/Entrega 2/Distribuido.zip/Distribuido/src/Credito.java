import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author Juan Vales
 */
public interface Credito extends Remote
{
    public int getBalance() throws RemoteException;
    public int setBalance(int balance) throws RemoteException;
}
