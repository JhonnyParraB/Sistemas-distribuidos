import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author Juan Vales
 */
public interface MasterCard extends Remote
{
    public int getCupoMC() throws RemoteException;
    public int setCupoMC(int balance) throws RemoteException;
    public int getDeudaMC() throws RemoteException;
    public int setDeudaMC(int balance) throws RemoteException;
    
}
