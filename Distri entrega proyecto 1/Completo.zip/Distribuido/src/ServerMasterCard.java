
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Juan Vales
 */
public class ServerMasterCard extends UnicastRemoteObject implements MasterCard
{
    
    private int Deuda=3700000;
    private int Cupo=5000000;
    
    public ServerMasterCard()throws RemoteException
    {
        super();
    }

    @Override
    public int getDeudaMC() throws RemoteException {
        return Deuda;
    }

    @Override
    public int setDeudaMC(int balance) throws RemoteException {
        Deuda=balance;
        return Deuda;
    }
    @Override
    public int getCupoMC() throws RemoteException {
        return Cupo-Deuda;
    }

    @Override
    public int setCupoMC(int balance) throws RemoteException {
        Cupo=balance;
        return Cupo;
    }    
    
    public static void main (String args[])
    {
        try
        {
            Registry reg = LocateRegistry.createRegistry(4442);
            
            reg.rebind("12345", new ServerMasterCard());
            reg.rebind("56789", new ServerMasterCard());
            reg.rebind("13579", new ServerMasterCard());
            reg.rebind("24568", new ServerMasterCard());
            reg.rebind("00000", new ServerMasterCard());
            reg.rebind("11335", new ServerMasterCard());
            
            System.out.println("Server MasterCard preparado para conexiones: ");
        }
        catch (RemoteException e)
        {
            
            System.out.println("Exception" +e); 
        }
        
        
    }

   
}