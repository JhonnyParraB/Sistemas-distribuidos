import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author Juan Vales
 */
public interface Visa extends Remote
{
    public int getCupoVisa() throws RemoteException;
    public int setCupoVisa(int balance) throws RemoteException;
    public int getDeudaVisa() throws RemoteException;
    public int setDeudaVisa(int balance) throws RemoteException;
}

