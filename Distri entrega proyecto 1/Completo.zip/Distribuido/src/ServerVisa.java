
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Juan Vales
 */
public class ServerVisa extends UnicastRemoteObject implements Visa
{
    
    private int Deuda=260000;
    private int Cupo=1000000;
    
    public ServerVisa()throws RemoteException
    {
        super();
    }

    @Override
    public int getDeudaVisa() throws RemoteException {
        return Deuda;
    }

    @Override
    public int setDeudaVisa(int balance) throws RemoteException {
    	if(balance>Deuda)
    		Deuda=0;
        Deuda=balance;
        return Deuda;
    }
    @Override
    public int getCupoVisa() throws RemoteException {
        return Cupo-Deuda;
    }

    @Override
    public int setCupoVisa(int balance) throws RemoteException {
        Cupo=balance;
        return Cupo;
    }    
    
    public static void main (String args[])
    {
        try
        {
            Registry reg = LocateRegistry.createRegistry(4443);
            
            reg.rebind("12345", new ServerVisa());
            reg.rebind("56789", new ServerVisa());
            reg.rebind("13579", new ServerVisa());
            reg.rebind("24568", new ServerVisa());
            reg.rebind("00000", new ServerVisa());
            reg.rebind("11335", new ServerVisa());
            
            System.out.println("Server visa preparado para conexiones: ");
        }
        catch (RemoteException e)
        {
            
            System.out.println("Exception" +e); 
        }
        
        
    }

   
}