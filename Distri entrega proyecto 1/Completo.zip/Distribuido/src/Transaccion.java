

import java.io.Serializable;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;


public class Transaccion  implements Serializable{
	
	public String peticion;
	public String estado;
	public String usrName;
	public int monto;
	public GregorianCalendar startTn;
	public GregorianCalendar validacionTn;
	public GregorianCalendar finishTn;
	
	
	public Transaccion(String usrName, String peticion, int monto) {
		super();
		this.usrName=usrName;
		this.peticion=peticion;
		this.monto=monto;
		estado="Iniciado";
		startTn=new GregorianCalendar();
	
		finishTn=null;
	}


	@Override
	public String toString() {
		return "Transaccion [peticiones=" + peticion + ", copiaCuentas=" + /*copiaCuentas +*/ ", estado=" + estado
				+ ", usrName=" + usrName + "]";
	}


	public GregorianCalendar getStartTn() {
		return startTn;
	}


	public void setStartTn(GregorianCalendar startTn) {
		this.startTn = startTn;
	}
 }
