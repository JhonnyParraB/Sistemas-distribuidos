import java.rmi.RemoteException;
import java.util.ArrayList;

public class Participante {
	private Coordinador coordinador;
	private int tentativa1;
	private int tentativa2;
        private int tentativa3;

	public Participante(Coordinador coordinador) {
		super();
		this.coordinador = coordinador;
	}
	public boolean canComit(ArrayList<Transaccion> transaccions,Transaccion transaccion, VisaAhorro ad, VisaAhorro ad2) throws RemoteException {
		if(ad.getBalance()<transaccion.monto)
			return false;
		for(Transaccion t: transaccions) {
			if (t.peticion.equalsIgnoreCase("transferencia")&&t.startTn.after(transaccion.startTn)&&transaccion.peticion.equals("write")) {
				return false;
				
			}
		}
		tentativa1=ad.getBalance()-transaccion.monto;
		System.out.println(tentativa1+ " "+ tentativa2);
		tentativa2=ad2.getBalance()+transaccion.monto;
		System.out.println(tentativa2);
		
		return true;
	}
	public void doCommit(VisaAhorro ad, VisaAhorro ad2) throws RemoteException {
		ad.setBalance(tentativa1);
		ad2.setBalance(tentativa2);
	}
	public boolean canComit(ArrayList<Transaccion> listaTransacciones, Transaccion transaccion, VisaAhorro ad, MCAhorro cd) throws RemoteException {
		// TODO Auto-generated method stub
		if(ad.getBalance()<transaccion.monto)
			return false;
		for(Transaccion t: listaTransacciones) {
			if (t.peticion.equalsIgnoreCase("transferencia")&&t.startTn.after(transaccion.startTn)&&transaccion.peticion.equals("write")) {
				return false;
				
			}
		}
		tentativa1=ad.getBalance()-transaccion.monto;
		tentativa2=cd.getBalance()+transaccion.monto;
		
		return true;
		
	}
	public void doCommit(VisaAhorro ad, MCAhorro cd) throws RemoteException {
		// TODO Auto-generated method stub
		ad.setBalance(tentativa1);
		cd.setBalance(tentativa2);
	}
	public boolean canComit(ArrayList<Transaccion> listaTransacciones, Transaccion transaccion, MCAhorro cd, VisaAhorro ad) throws RemoteException {
		// TODO Auto-generated method stub
		if(cd.getBalance()<transaccion.monto)
			return false;
		for(Transaccion t: listaTransacciones) {
			if (t.peticion.equalsIgnoreCase("transferencia")&&t.startTn.after(transaccion.startTn)&&transaccion.peticion.equals("write")) {
				return false;
				
			}
		}
		tentativa1=cd.getBalance()-transaccion.monto;
		tentativa2=ad.getBalance()+transaccion.monto;
		
		return true;
	}

	public boolean canComit(ArrayList<Transaccion> listaTransacciones, Transaccion transaccion, MCAhorro cd,
			MCAhorro cd2) throws RemoteException {
		// TODO Auto-generated method stub
		if(cd.getBalance()<transaccion.monto)
			return false;
		for(Transaccion t: listaTransacciones) {
			if (t.peticion.equalsIgnoreCase("Transferencia")&&t.startTn.after(transaccion.startTn)&&transaccion.peticion.equals("write")) {
				return false;
				
			}
		}
		tentativa1=cd.getBalance()-transaccion.monto;
		tentativa2=cd2.getBalance()+transaccion.monto;
		
		return true;
	
	}
	public void doCommit(MCAhorro cd, MCAhorro cd2) throws RemoteException {
		// TODO Auto-generated method stub
		cd.setBalance(tentativa1);
		cd2.setBalance(tentativa2);
		
	}
	public boolean canComit(ArrayList<Transaccion> listaTransacciones, Transaccion transaccion, Visa vd, VisaAhorro ad) throws RemoteException {
		// TODO Auto-generated method stub
		if(ad.getBalance()<transaccion.monto)
			return false;
		for(Transaccion t: listaTransacciones) {
			if (t.peticion.equalsIgnoreCase("pagar")&&t.startTn.after(transaccion.startTn)&&transaccion.peticion.equals("write")) {
				return false;
				
			}
		}
		tentativa1=ad.getBalance()-transaccion.monto;
		tentativa2=vd.getDeudaVisa()-transaccion.monto;
		
		return true;
	}
	public void doCommit(Visa vd, VisaAhorro ad) throws RemoteException {
		ad.setBalance(tentativa1);
		vd.setDeudaVisa(tentativa2);
		// TODO Auto-generated method stub
		
	}
	public boolean canComit(ArrayList<Transaccion> listaTransacciones, Transaccion transaccion, Visa vd, MCAhorro cd) throws RemoteException {
		// TODO Auto-generated method stub
		if(cd.getBalance()<transaccion.monto)
			return false;
		for(Transaccion t: listaTransacciones) {
			if (t.peticion.equalsIgnoreCase("Pagar")&&t.startTn.after(transaccion.startTn)&&transaccion.peticion.equals("write")) {
				return false;
				
			}
		}
		tentativa1=cd.getBalance()-transaccion.monto;
		tentativa2=vd.getDeudaVisa()-transaccion.monto;
		
		return true;
	}
	public void doCommit(MCAhorro cd, VisaAhorro ad) throws RemoteException {
		// TODO Auto-generated method stub
		cd.setBalance(tentativa1);
		ad.setBalance(tentativa2);
		
	}
	public void doCommit(Visa vd, MCAhorro cd) throws RemoteException {
		cd.setBalance(tentativa1);
		vd.setDeudaVisa(tentativa2);
	}
	public void doCommit(VisaAhorro ad, MasterCard md) throws RemoteException {
		// TODO Auto-generated method stub
		ad.setBalance(tentativa1);
		md.setDeudaMC(tentativa2);
		
	}
	public boolean canComit(ArrayList<Transaccion> listaTransacciones, Transaccion transaccion, VisaAhorro ad,
			MasterCard md) throws RemoteException {
		// TODO Auto-generated method stub
		
		if(ad.getBalance()<transaccion.monto)
			return false;
		for(Transaccion t: listaTransacciones) {
			if (t.peticion.equalsIgnoreCase("Pagar")&&t.startTn.after(transaccion.startTn)&&transaccion.peticion.equals("write")) {
				return false;
				
			}
		}
		tentativa1=ad.getBalance()-transaccion.monto;
		tentativa2=md.getDeudaMC()-transaccion.monto;
		
		return true;
	}
	public boolean canComit(ArrayList<Transaccion> listaTransacciones, Transaccion transaccion, MCAhorro cd,
			MasterCard md) throws RemoteException {
		// TODO Auto-generated method stub
		
		if(cd.getBalance()<transaccion.monto)
			return false;
		for(Transaccion t: listaTransacciones) {
			if (t.peticion.equalsIgnoreCase("Pagar")&&t.startTn.after(transaccion.startTn)&&transaccion.peticion.equals("write")) {
				return false;
				
			}
		}
		tentativa1=cd.getBalance()-transaccion.monto;
		tentativa2=md.getDeudaMC()-transaccion.monto;
		
		return true;
	}
	public void doCommit(MCAhorro cd, MasterCard md) throws RemoteException {
		// TODO Auto-generated method stub
		cd.setBalance(tentativa1);
		md.setDeudaMC(tentativa2);
		
	}
        public boolean canComit(ArrayList<Transaccion> listaTransacciones, Transaccion transaccion, 
                MCAhorro cd,Visa vd, MasterCard md) throws RemoteException {
		// TODO Auto-generated method stub
		
		if(cd.getBalance()<transaccion.monto)
			return false;
		for(Transaccion t: listaTransacciones) {
			if (t.peticion.equalsIgnoreCase("Pagar")&&t.startTn.after(transaccion.startTn)&&transaccion.peticion.equals("write")) {
				return false;
				
			}
		}
		tentativa1=cd.getBalance()-(2*transaccion.monto);
		tentativa2=md.getDeudaMC()-transaccion.monto;
                tentativa3=vd.getDeudaVisa()-transaccion.monto;
		
		return true;
	}
        public void doCommit(MCAhorro cd, Visa vd, MasterCard md) throws RemoteException {
		// TODO Auto-generated method stub
		cd.setBalance(tentativa1);
		md.setDeudaMC(tentativa2);
                vd.setDeudaVisa(tentativa3);
		
	}
        public boolean canComit(ArrayList<Transaccion> listaTransacciones, Transaccion transaccion, 
                VisaAhorro ad,Visa vd, MasterCard md) throws RemoteException {
		// TODO Auto-generated method stub
		
		if(ad.getBalance()<transaccion.monto)
			return false;
		for(Transaccion t: listaTransacciones) {
			if (t.peticion.equalsIgnoreCase("Pagar")&&t.startTn.after(transaccion.startTn)&&transaccion.peticion.equals("write")) {
				return false;
				
			}
		}
		tentativa1=ad.getBalance()-(2*transaccion.monto);
		tentativa2=md.getDeudaMC()-transaccion.monto;
                tentativa3=vd.getDeudaVisa()-transaccion.monto;
		
		return true;
	}
        public void doCommit(VisaAhorro ad, Visa vd, MasterCard md) throws RemoteException {
		// TODO Auto-generated method stub
		ad.setBalance(tentativa1);
		md.setDeudaMC(tentativa2);
                vd.setDeudaVisa(tentativa3);
		
	}
}
