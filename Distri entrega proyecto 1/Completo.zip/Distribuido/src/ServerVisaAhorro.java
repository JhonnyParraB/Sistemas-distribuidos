
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Juan Vales
 */
public class ServerVisaAhorro extends UnicastRemoteObject implements VisaAhorro 
{
    private int saldoInicial=500000;
    
    
    public ServerVisaAhorro()throws RemoteException
    {
        super();
    }

    @Override
    public int getBalance() throws RemoteException {
        return saldoInicial;
    }

    @Override
    public int setBalance(int balance) throws RemoteException {
        saldoInicial=balance;
        return saldoInicial;
    }
    
    
    public static void main (String args[])
    {
        try
        {
            Registry reg = LocateRegistry.createRegistry(4444);
            
            reg.rebind("12345", new ServerVisaAhorro());
            reg.rebind("56789", new ServerVisaAhorro());
            reg.rebind("13579", new ServerVisaAhorro());
            reg.rebind("24568", new ServerVisaAhorro());
            reg.rebind("00000", new ServerVisaAhorro());
            reg.rebind("11335", new ServerVisaAhorro());
            
            System.out.println("Server ahorro preparado para conexiones: ");
        }
        catch (RemoteException e)
        {
            
            System.out.println("Exception" +e); 
        }
        
        
    }

   
}
