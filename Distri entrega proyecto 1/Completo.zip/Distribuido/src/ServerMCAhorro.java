
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Juan Vales
 */
public class ServerMCAhorro extends UnicastRemoteObject implements MCAhorro
{
    
    private int saldoInicial=100000;
    
    
    public ServerMCAhorro()throws RemoteException
    {
        super();
    }

    @Override
    public int getBalance() throws RemoteException {
        return saldoInicial;
    }

    @Override
    public int setBalance(int balance) throws RemoteException {
        saldoInicial=balance;
        return saldoInicial;
    }
    
    
    public static void main (String args[])
    {
        try
        {
            Registry reg = LocateRegistry.createRegistry(4445);
            
            reg.rebind("12345", new ServerMCAhorro());
            reg.rebind("56789", new ServerMCAhorro());
            reg.rebind("13579", new ServerMCAhorro());
            reg.rebind("24568", new ServerMCAhorro());
            reg.rebind("00000", new ServerMCAhorro());
            reg.rebind("11335", new ServerMCAhorro());
            
            System.out.println("Server credito preparado para conexiones: ");
        }
        catch (RemoteException e)
        {
            
            System.out.println("Exception" +e); 
        }
        
        
    }

   
}