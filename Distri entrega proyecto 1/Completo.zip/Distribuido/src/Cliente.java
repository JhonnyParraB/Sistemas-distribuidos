
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Juan Vales
 */
public class Cliente 
{

    public static void main(String args[]) throws RemoteException
    {
        
        Cliente c = new Cliente();
      
        c.connectRemote();
        
    }
   

	private void connectRemote()
    {
        try
        {
            
            System.err.println("Bienvenido ");
            System.out.println(" ");
            System.out.println("A. Ingresar");
            System.out.println("B. Salir");
            Scanner inicio = new Scanner(System.in);
            String seleccion = inicio.next();
            
            if(seleccion.equalsIgnoreCase("A"))
            {
                
                System.err.println("Digite su usuario: ");
                Scanner capt = new Scanner(System.in);
                String user = capt.next();
                String salir = "False";
                Registry reg = LocateRegistry.getRegistry("localHost", 4444);
                Registry reg2 = LocateRegistry.getRegistry("localHost", 4445);
                Registry reg3 = LocateRegistry.getRegistry("localHost", 4443);
                Registry reg4 = LocateRegistry.getRegistry("localHost", 4442);
                Registry regi = LocateRegistry.getRegistry("localHost", 1234);
                CoordinadorIF coordinador=(CoordinadorIF) regi.lookup(user);
                VisaAhorro ad = (VisaAhorro) reg.lookup(user);
                MCAhorro cd = (MCAhorro) reg2.lookup(user);
                Visa vd = (Visa) reg3.lookup(user);
                MasterCard md = (MasterCard) reg4.lookup(user);
                int cantidad=0;
                
                
                while (salir.equalsIgnoreCase("False"))
                {
                    System.err.println("Seleccione una opcion: ");
                    System.out.println(" ");
                    System.out.println("A. Consultar Saldo");
                    System.out.println("B. Transferir");
                    System.out.println("C. Pagar");
                    System.out.println("D. Salir");
                    Scanner opcion = new Scanner(System.in);
                    String selec = opcion.next();
                    if(selec.equalsIgnoreCase("D"))
                   {
                       
                       salir = "True";

                   }
             
                    
                    if(selec.equalsIgnoreCase("A"))
                    {
                        
                        System.err.println("Tipo de cuenta: ");
                        System.out.println(" ");
                        System.out.println("A. Visa Ahorros");
                        System.out.println("B. MasterCard Ahorros");
                        System.out.println("C. Visa Credito");
                        System.out.println("D. MasterCard Credito");
                        System.out.println("E. Todos");
                        Scanner opcion2 = new Scanner(System.in);
                        String selec2 = opcion2.next();

                        if(selec2.equalsIgnoreCase("A"))
                        {
                        	System.out.println("Su balance en la tajeta Visa de Ahorros" + coordinador.openTransacccion(user, selec, ad, null, null, null, 0));
                            System.out.println(" ");
                            
                           // System.out.println("Su balance actual es: " + ad.getBalance());   
                        }
                        if(selec2.equalsIgnoreCase("B"))
                        {
                        	System.out.println("Su balance en la tajeta MasterCard de Ahorros" +coordinador.openTransacccion(user, selec, null, cd, null, null, 0));
                            System.out.println(" ");
                          //  System.out.println("Su balance actual es: " + cd.getBalance());   
                        }
                        if(selec2.equalsIgnoreCase("C"))
                        {
                        	System.out.println("Su balance en la tajeta Visa de Credito" +coordinador.openTransacccion(user, selec, null, null, vd, null, 0));
                            System.out.println(" ");
                           // System.out.println("El cupo actual de su tarjeta visa es: " + vd.getCupoVisa());
                            //System.out.println("La deuda actual de su tarjeta visa es: " + vd.getDeudaVisa());
                        }
                        if(selec2.equalsIgnoreCase("D"))
                        {
                        	System.out.println("Su balance en la tajeta MasterCard de Credito" +coordinador.openTransacccion(user, selec, null, null, null, md, 0));
                            System.out.println(" ");
                            //System.out.println("El cupo actual de su tarjeta MasterCard es: " + md.getCupoMC());
                            //System.out.println("La deuda actual de su tarjeta MasterCard es: " + md.getDeudaMC());
                        }
                        if(selec2.equalsIgnoreCase("E"))
                        {
                        	System.out.println(coordinador.openTransacccion(user, selec, ad, cd, vd, md, 0));
                            System.out.println(" ");
                            /*System.out.println("El balance de la cuenta de ahorros es: " + ad.getBalance());
                            System.out.println("El balance de la cuenta de credito es: " + cd.getBalance());
                            System.out.println("El cupo actual de su tarjeta visa es: " + vd.getCupoVisa());
                            System.out.println("La deuda actual de su tarjeta visa es: " + vd.getDeudaVisa());
                            System.out.println("El cupo actual de su tarjeta MasterCard es: " + md.getCupoMC());
                            System.out.println("La deuda actual de su tarjeta MasterCard es: " + md.getDeudaMC());*/
                        }

                    }

                    if(selec.equalsIgnoreCase("B"))
                    {
                        
                        System.err.println("Monto a transferir: ");
                        Scanner monto = new Scanner(System.in);
                        String total = monto.next();
                        int result = Integer.valueOf(total);
                        System.err.println("Tipo de cuenta origen: ");
                        System.out.println(" ");
                        System.out.println("A. Visa Ahorros");
                        System.out.println("B. MasterCard Ahorros");
                        Scanner opcionTT = new Scanner(System.in);
                        String selecTT = opcionTT.next();
                        
                        if(selecTT.equalsIgnoreCase("A"))
                        {
                            
                            System.err.println("Digite la cuenta destino: ");
                            Scanner capt2 = new Scanner(System.in);
                            String user2 = capt2.next();
                            System.err.println("Tipo de cuenta destino: ");
                            System.out.println(" ");
                            System.out.println("A. Visa Ahorros");
                            System.out.println("B. MasterCard Ahorros");
                            Scanner opcionT = new Scanner(System.in);
                            String selecT = opcionT.next();

                            if(selecT.equalsIgnoreCase("A"))
                            {
                                
                                Registry regT = LocateRegistry.getRegistry("localHost", 4444);
                                VisaAhorro ad2 = (VisaAhorro) regT.lookup(user2);
                                System.out.println("Su nuevo balance es:: "+coordinador.openTransacccion(user, selec, ad, ad2, result));
                                //System.out.println(" ");
                                //System.out.println("Su nuevo balance es: " + ad.setBalance(-result));
                                //ad2.setBalance(result); 
                                
                            }

                            if(selecT.equalsIgnoreCase("B"))
                            {
                                
                                Registry regT = LocateRegistry.getRegistry("localHost", 4445);
                                MCAhorro cd2 = (MCAhorro) regT.lookup(user2);
                               
                                System.out.println(" ");
                                System.out.println(coordinador.openTransacccion(user, "0", ad, cd2, result));
                               // System.out.println("Su nuevo balance es: " + ad.setBalance(-result));
                                //cd2.setBalance(result);  
                                
                            }  
                        }
                        
                        if(selecTT.equalsIgnoreCase("B"))
                        {
                            
                            System.err.println("Digite la cuenta destino: ");
                            Scanner capt2 = new Scanner(System.in);
                            String user2 = capt2.next();
                            System.err.println("Tipo de cuenta destino: ");
                            System.out.println(" ");
                            System.out.println("A. Visa Ahorros");
                            System.out.println("B. MasterCard Ahorros");
                            Scanner opcionT = new Scanner(System.in);
                            String selecT = opcionT.next();

                            if(selecT.equalsIgnoreCase("A"))
                            {
                                
                                Registry regT = LocateRegistry.getRegistry("localHost", 4444);
                                VisaAhorro ad2 = (VisaAhorro) regT.lookup(user2);
                                System.out.println(" ");
                                System.out.println(coordinador.openTransacccion(user, "1", ad2, cd, result));
                               // System.out.println("Su nuevo balance es: " + cd.setBalance(-result));
                             //   ad2.setBalance(result);
                                
                            }

                            if(selecT.equalsIgnoreCase("B"))
                            {
                                
                                Registry regT = LocateRegistry.getRegistry("localHost", 4445);
                                MCAhorro cd2 = (MCAhorro) regT.lookup(user2);
                                System.out.println(" ");
                                System.out.println(coordinador.openTransacccion(user, selec, cd2, cd, result));
                                System.out.println("Su nuevo balance es: " + cd.setBalance(-result));
                                cd2.setBalance(result);  
                                
                            }  
                        }
                        
                    }
                    
                    if(selec.equalsIgnoreCase("C"))
                    {
                        System.err.println("Seleccione la tarjeta a pagar: ");
                        System.out.println(" ");
                        System.out.println("A. Visa Credito");
                        System.out.println("B. MasterCard Credito");
                        System.out.println("C. Todas");
                        Scanner opcionT = new Scanner(System.in);
                        String selecT = opcionT.next();

                        if(selecT.equalsIgnoreCase("A"))
                        {
                            System.err.println("Cuenta de la cual paga: ");
                            System.out.println(" ");
                            System.out.println("A. Visa Ahorros");
                            System.out.println("B. MasterCard Ahorros");
                            Scanner opcionTT = new Scanner(System.in);
                            String selecTT = opcionTT.next();

                            if(selecTT.equalsIgnoreCase("A"))
                            {
                                System.err.println("Monto a pagar: ");
                                Scanner monto2 = new Scanner(System.in);
                                String totalP = monto2.next();
                                int result = Integer.valueOf(totalP);
                                System.out.println(" ");
                                System.out.println(coordinador.openTransacccion(user, selec, ad, null, vd, null, result));
                                //System.out.println("Su balance en ahorros luego de pagar es: " + ad.setBalance(-result));
                                //System.out.println("Su deuda actual es: " + vd.setDeudaVisa(result));
                               // System.out.println("Su cupo actual es: " + vd.getCupoVisa());
                                
                                
                            }

                            if(selecTT.equalsIgnoreCase("B"))
                            {
                                
                                System.err.println("Monto a pagar: ");
                                Scanner monto2 = new Scanner(System.in);
                                String totalP = monto2.next();
                                int result = Integer.valueOf(totalP);
                                System.out.println(" ");
                                System.out.println(coordinador.openTransacccion(user, selec, null, cd, vd, null, result));
                                //System.out.println("Su balance en credito luego de pagar es: " + cd.setBalance(-result));
                                //System.out.println("Su deuda actual es: " + vd.setDeudaVisa(result));
                                //System.out.println("Su cupo actual es: " + vd.getCupoVisa());
                                
                            } 
                           
                        }

                        if(selecT.equalsIgnoreCase("B"))
                        {   
                            System.err.println("Cuenta de la cual paga: ");
                            System.out.println(" ");
                            
                            System.out.println("A. Visa Ahorros");
                            System.out.println("B. MasterCard Ahorros");
                            Scanner opcionTT = new Scanner(System.in);
                            String selecTT = opcionTT.next();

                            if(selecTT.equalsIgnoreCase("A"))
                            {
                                System.err.println("Monto a pagar: ");
                                Scanner monto2 = new Scanner(System.in);
                                String totalP = monto2.next();
                                int result = Integer.valueOf(totalP);
                                System.out.println(" ");
                                System.out.println(coordinador.openTransacccion(user, selec, ad, null, null, md, result));
                               // System.out.println("Su balance en ahorros luego de pagar es: " + ad.setBalance(-result));
                               // System.out.println("Su deuda actual es: " + md.setDeudaMC(result));
                                //System.out.println("Su cupo actual es: " + md.getCupoMC());
                                
                                
                            }

                            if(selecTT.equalsIgnoreCase("B"))
                            {
                                
                                System.err.println("Monto a pagar: ");
                                Scanner monto2 = new Scanner(System.in);
                                String totalP = monto2.next();
                                int result = Integer.valueOf(totalP);
                                System.out.println(" ");
                                System.out.println(coordinador.openTransacccion(user, selec, null, cd, null, md, result));
                                //System.out.println("Su balance en credito luego de pagar es: " + cd.setBalance(-result));
                                //System.out.println("Su deuda actual es: " + md.setDeudaMC(result));
                                //System.out.println("Su cupo actual es: " + md.getCupoMC());
                                
                            }                            
        
                        }
                        if(selecT.equalsIgnoreCase("C"))
                        {
                            System.err.println("Cuenta de la cual paga: ");
                            System.out.println(" ");
                            System.out.println("A. Visa Ahorros");
                            System.out.println("B. MasterCard Ahorros");
                            Scanner opcionTT = new Scanner(System.in);
                            String selecTT = opcionTT.next();

                            if(selecTT.equalsIgnoreCase("A"))
                            {
                                System.err.println("Monto a pagar: ");
                                Scanner monto2 = new Scanner(System.in);
                                String totalP = monto2.next();
                                int result = Integer.valueOf(totalP);
                                System.out.println(" ");
                                System.out.println(coordinador.openTransacccion(user, selec, ad, cd, vd, md, result));
                                //System.out.println("Visa Ahorros: " + ad.setBalance(2*(-result))+ "Deuda Visa: " + vd.setDeudaVisa(result) + "Cupo Visa: " + 
                                       // vd.getCupoVisa() + "Deuda MasterCard: " + md.setDeudaMC(result) +"Cupo MasterCard: " + md.getCupoMC());
                                
                                
                                
                            }

                            if(selecTT.equalsIgnoreCase("B"))
                            {
                                
                                System.err.println("Monto a pagar: ");
                                Scanner monto2 = new Scanner(System.in);
                                String totalP = monto2.next();
                                int result = Integer.valueOf(totalP);
                                System.out.println(" ");
                                System.out.println(coordinador.openTransacccion(user, selec, ad, cd, vd, md, result));
                                //System.out.println("Visa Ahorros: " + cd.setBalance(2*(-result))+ "Deuda Visa: " + vd.setDeudaVisa(result) + "Cupo Visa: " + 
                                         // vd.getCupoVisa() + "Deuda MasterCard: " + md.setDeudaMC(result) +"Cupo MasterCard: " + md.getCupoMC());

                            } 
        
                        }

                    }

                }
                
            }
            
        }
        catch(NotBoundException|RemoteException e)
        {
            System.out.println("Exception: " +e);
        }
        
        
    }
}
