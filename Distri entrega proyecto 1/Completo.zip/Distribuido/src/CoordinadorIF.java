import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author Juan Vales
 */
public interface CoordinadorIF extends Remote
{
    

	public String openTransacccion(String user, String selec, VisaAhorro ad, MCAhorro cd, Visa vd, MasterCard md, int cantidad) throws RemoteException;

	public String openTransacccion(String user, String selec, MasterCard md, int cantidad)throws RemoteException;

	public String openTransacccion(String user, String selec, MCAhorro cd, int cantidad)throws RemoteException;

	public String openTransacccion(String user, String selec, VisaAhorro ad, int cantidad)throws RemoteException;

	public String openTransacccion(String user, String selec, VisaAhorro ad, VisaAhorro ad2, int result)throws RemoteException; //transferencia ahorro a ahorro;

	public String openTransacccion(String user, String selec, VisaAhorro ad, MCAhorro cd, int result) throws RemoteException;

	public String openTransacccion(String user, String selec, MCAhorro cd, MCAhorro cd2, int result) throws RemoteException;
}
